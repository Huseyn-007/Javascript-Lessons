// let jsonText = `
//     {
//         "students":[
//             {"name":"Leyla","surname":"Mammadli"},
//             {"name":"Aysel","surname":"Eliyeva"},
//             {"name":"Tural","surname":"Hesenli"},
//             {"name":"Vusal","surname":"Haciyev"}

//         ]
//     }

// `;

// console.log(jsonText);

// //
// const myheader = document.querySelector('#demo');

// let obj = JSON.parse(jsonText); // stringi jsona cevirir

// obj.students.forEach(s => {
//     myheader.innerHTML += s.name + ' - ';
//     myheader.innerHTML += s.surname + ' </br> ';
// });

// let jsonString2 = JS ON.stringify(jsonText) // jsonu stringe cevirir

// Promise C# daki Task classini evez edir

// async function MyFunction() {
//   return 1;
// }

// async function ForCallAsync() {
//   let result = await MyFunction();
//   const header = document.querySelector("#demo");
//   header.innerHTML = result;
// }

// then ve catch callBack funksiyyalardir yeni funksiyya bitdikden sonra avtomatikolaraq cagrilir

//Eger function ugurla islese then in icine girir
//Eger her hansi bir problem olsa catcin icine girir
// Finally problem olsada olmasada isleyir

// ForCallAsync()
//   .then(() => {
//     setTimeout(() => {
//       alert("call back complated");
//       const header = document.querySelector("#demo");
//       header.innerHTML = "Call back isledi";
//     }, 2000);
//   })
//   .catch((e) => {
//     console.error("error: " + e);
//   })
//   .finally(() => {
//     console.log("asdas");
//   });

// const myfunc=(async(e)=>{
//     return 100;

// }

// );

const header = document.querySelector("#demo");
async function GetCarsCallAsync() {
  const url = "http://localhost:3000/cars";
  const xhr = new XMLHttpRequest();
  xhr.open("GET", url);

  xhr.onload = function () {
    console.log(xhr.status);
    if (xhr.status > 200) {
      header.innerHTML = xhr.statusText;
    } else {
      header.innerHTML = xhr.response;
      console.log(xhr.statusText);
      const data = JSON.parse(xhr.responseText);
      console.log(data);
    }
  };

  xhr.send();
}

async function GetCars() {
  GetCarsCallAsync()
    .then(() => {
      console.log("Callback call");
    })
    .catch((e) => {
      header.innerHTML = e;
    })
    .finally(() => {
      console.log("fuinak");
    }); 
}
